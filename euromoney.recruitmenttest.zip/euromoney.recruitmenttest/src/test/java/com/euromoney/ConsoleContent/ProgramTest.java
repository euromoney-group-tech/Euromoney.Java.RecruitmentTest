package com.euromoney.ConsoleContent;

import java.io.IOException;

import org.junit.Test;

public class ProgramTest {

	@Test
	public final void testMain() throws IOException {
		
	}

}
